﻿using System;

namespace CarManufacturer
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            string make = Console.ReadLine();
            string model = Console.ReadLine();
            int year = int.Parse(Console.ReadLine());
            double fuelQuantity = double.Parse(Console.ReadLine());
            double fuelConsumption = double.Parse(Console.ReadLine());

            Car firstCar = new Car();
            Car secondCar = new Car(make, model, year);
            Car thirdCar = new Car(make, model, year, fuelQuantity, fuelConsumption);

            var tires = new Tire[4]
            {
                new Tire(1995,2.5),
                new Tire(2005,2.1),
                new Tire(2005,0.5),
                new Tire(1995, 2.3)
            };

            var engine = new Engine(560, 6300);

            var car = new Car("Lamborghini", "Urus", 2010, 250, 9, engine, tires);

            Console.WriteLine($"Model: {car.Model}");
            Console.WriteLine($"Make: {car.Make}");
            Console.WriteLine($"Year: {car.Year}");
            Console.WriteLine($"FuelQuantity: {car.FuelQuantity}");
            Console.WriteLine($"FuelConsumption: {car.FuelConsumption}");
            Console.WriteLine($"HorsePower: {car.Engine.HorsePower}");
            Console.WriteLine($"CubicCapacity: {car.Engine.CubicCapacity}");

            int count = 1;

            foreach (var item in car.Tires)
            {
                Console.WriteLine($"{count}.Year: {item.Year} | {item.Pressure}");
                count++;
            }




        }
    }
}
