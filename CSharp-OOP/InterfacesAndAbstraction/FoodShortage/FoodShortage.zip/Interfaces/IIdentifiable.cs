﻿namespace FoodShortage.Interfaces
{
    public interface IIdentifiable
    {
        public string ID { get; }
    }
}
