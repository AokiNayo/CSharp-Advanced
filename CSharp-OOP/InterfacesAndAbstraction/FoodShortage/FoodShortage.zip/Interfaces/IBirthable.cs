﻿namespace FoodShortage.Interfaces
{
    interface IBirthable
    {
        public string Birthdate { get;}

    }
}
