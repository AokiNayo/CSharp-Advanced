﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    public abstract class Vehicle
    {
        protected double fuelQuantity;
        protected double fuelConsumption;
        protected double tankCapacity;

        public Vehicle(double fuelQuantity, double litersPerKM, double tankCapacity)
        {
            this.fuelQuantity = fuelQuantity;
            this.fuelConsumption = litersPerKM;
            this.tankCapacity = tankCapacity;
        }
        public double FuelQuantity
        {
            get => this.fuelQuantity;
            protected set
            {
                if (value > tankCapacity)
                {
                    this.fuelQuantity = 0;
                }
                else
                {
                    this.fuelQuantity = value;
                }
            }
        }
        public abstract void Drive(double distance);
        public abstract void Refuel(double liters);
    }
}
