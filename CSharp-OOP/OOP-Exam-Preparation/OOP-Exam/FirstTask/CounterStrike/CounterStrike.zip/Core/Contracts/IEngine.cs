﻿namespace CounterStrike.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
