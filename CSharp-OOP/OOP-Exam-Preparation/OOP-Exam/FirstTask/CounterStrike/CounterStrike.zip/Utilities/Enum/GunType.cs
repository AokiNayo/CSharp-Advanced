﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CounterStrike.Utilities.Enum
{
    public enum GunType
    {
        Pistol = 1,
        Rifle
    }
}
