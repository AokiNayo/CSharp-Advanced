﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CounterStrike.Utilities.Enum
{
    public enum PlayerType
    {
        Terrorist = 1,
        CounterTerrorist
    }
}
