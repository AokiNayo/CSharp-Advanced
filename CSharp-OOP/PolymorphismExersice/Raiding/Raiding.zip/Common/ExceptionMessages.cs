﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Raiding.Common
{
    public static class ExceptionMessages
    {
        public const string INVALID_HERO_MSG = "Invalid hero!";
    }
}
