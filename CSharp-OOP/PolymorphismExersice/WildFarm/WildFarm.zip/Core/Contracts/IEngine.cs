﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Core.Contracts
{
    interface IEngine
    {
        public void Run();
    }
}
