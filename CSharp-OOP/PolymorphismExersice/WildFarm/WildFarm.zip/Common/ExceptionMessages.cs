﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Common
{
    public static class ExceptionMessages
    {
        public const string INVALID_TYPE = "Invalid type!";
    }
}
